#!/bin/bash

### SPAdes Assembly Script

base_dir="$HOME/NGS/Genome_assembly"
trimmed_dir="$base_dir/trimgalore"
spades_dir="$base_dir/spades"

mkdir -p "$spades_dir"

echo "Choose SPADes run mode:"
echo "1: Default"
echo "2: Custom"
echo "3: Both"
read -p "Enter your choice (1/2/3):" mode

if [[ "$mode" == "2" || "$mode" == "3" ]]; then    
# If the user has chosen either 2nd or 3rd mode, then ask for the following -
	read -p "Enter no. of threads: " threads
	read -p "Enter memory in GB: " memory
	read -p "Enter coverage cutoff (either a no. or auto): " coverage_cutoff
fi

read -p "Enter sample ID(s) separated by space: " -a sample_ids

for sample in "${sample_ids[@]}"; do
	# Input files 
	read_1="$trimmed_dir/$sample/${sample}_1_val_1.fq.gz"
	read_2="$trimmed_dir/$sample/${sample}_2_val_2.fq.gz"
	if [[ -f "$read_1" && -f "$read_2" ]]; then
		if [[ "$mode" == "1" || "$mode" == "3" ]]; then
			echo "Running SPAdes (default) for $sample..."
			out_default="$spades_dir/${sample}_default"
			mkdir -p "$out_default"
			spades.py -1 "$read_1" -2 "$read_2" --phred-offset 33 -o "$out_default"
		fi
		if [[ "$mode" == "2" || "$mode" == "3" ]]; then
			echo "Running SPAdes (custom) for $sample..."
			out_custom="$spades_dir/${sample}_custom"
			mkdir -p "$out_custom"
			spades.py -1 "$read_1" -2 "$read_2" --careful --cov-cutoff "$coverage_cutoff" --phred-offset 33 -t "$threads" -m "$memory" -o "$out_custom"
		fi

		# Count the sequences in contigs and scaffolds for both default & custom cases.
		echo "Sequence counts for $sample: "
		[[ "$mode" == "1" || "$mode" == "3" ]] && {
			echo "Default:"
			grep -c "^>" "$out_default/contigs.fasta"
			grep -c "^>" "$out_default/scaffolds.fasta"
		}
		[[ "$mode" == "2" || "$mode" == "3" ]] && {
			echo "Custom:"
			grep -c "^>" "$out_custom/contigs.fasta"
			grep -c "^>" "$out_custom/scaffolds.fasta"
		}
	else
		echo "Trimmed FASTQ files missing for $sample."
	fi
done

