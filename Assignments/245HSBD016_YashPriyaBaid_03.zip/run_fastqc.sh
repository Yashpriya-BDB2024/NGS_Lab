#!/bin/bash

### FastQC script: takes sample IDs as input, processes corresponding .fastq.gz files from the raw_data folder.

# Define base paths.
base_dir="$HOME/NGS/Genome_assembly"
raw="$base_dir/raw_data"
out="$base_dir/fastqc"

mkdir -p "$out"    # Create output directory if it doesn't exist.

read -p "Enter sample ID(s) separated by space: " -a sample_ids

# Loop through each sample ID
for sample in "${sample_ids[@]}"; do
    # Construct input file names
    r1="$raw/${sample}_1.fastq.gz"
    r2="$raw/${sample}_2.fastq.gz"

    # Check if both files exist
    if [[ -f "$r1" && -f "$r2" ]]; then
        # Create sample-specific output folder
        sample_out="$out/$sample"
        mkdir -p "$sample_out"

        echo "Running FastQC for sample: $sample"
        fastqc "$r1" "$r2" -o "$sample_out"
    else
        echo "One or both FASTQ files for sample $sample not found in $raw"
    fi
done

