#!/bin/bash

### This script trims paired-end FASTQ files using TrimGalore
### It allows the user to set quality cutoff and stringency, or fall back to defaults.
### It also runs FastQC on the trimmed files.

base_dir="$HOME/NGS/Genome_assembly"
raw="$base_dir/raw_data"
out="$base_dir/trimgalore"
trimgalore="$HOME/NGS/Packages/TrimGalore/trim_galore"

mkdir -p "$out"    

read -p "Enter quality cutoff (default = 25): " quality
if [[ -z "$quality" ]]; then
    quality=25
fi

read -p "Enter stringency level (default = 5): " stringency
if [[ -z "$stringency" ]]; then
    stringency=5
fi

read -p "Enter sample ID(s) separated by space: " -a sample_ids

for sample in "${sample_ids[@]}"; do
    # Define paths to paired-end FASTQ files
    r1="$raw/${sample}_1.fastq.gz"
    r2="$raw/${sample}_2.fastq.gz"
    # Check if both files exist
    if [[ -f "$r1" && -f "$r2" ]]; then
        # Create output subdirectory for this sample
        sample_out="$out/$sample"
        mkdir -p "$sample_out"
        echo "Running TrimGalore for $sample (quality = $quality, stringency = $stringency)"
	"$trimgalore" --paired "$r1" "$r2" -q "$quality" --stringency "$stringency" --fastqc -o "$sample_out"
    else
        echo "One or both FASTQ files not found for sample: $sample"
    fi
done

