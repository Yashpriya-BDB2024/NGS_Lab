#!/bin/bash

# Check if a file was provided as argument
if [ -z "$1" ]; then
    echo "Usage: $0 <input_file.tsv>"
    exit 1
fi

# Assign the input filename to a variable
file="$1"

# Read the header line and split it by tab using tr
# Use grep -n to find which column contains "fastq_ftp"
# Extract just the column number using cut
col=$(head -n 1 "$file" | tr '\t' '\n' | grep -n '^fastq_ftp$' | cut -d: -f1)

# Check if column number was found
if [ -z "$col" ]; then
    echo "fastq_ftp column not found in file."
    exit 1
fi

# Use cut to extract that column and save it to a new file
cut -f"$col" "$file" > fastq_ftp_links.txt

